#!usr/bin/perl
#random_permutation_analysis
use warnings;



$exp_name = $ARGV[0]; #print "exp_name is $exp_name\n";
$chrom = $ARGV[1];  #print "chrom is $chrom\n";
$replicate = $ARGV[2]; #print "replicate is $replicate\n";
$data_thres = $ARGV[3]; #print "Data threshold is $data_thres\n";
$dir = $ARGV[4]; # root directory path
print"\nRandom permuation analysis\n";

use List::Util 'shuffle';

$max_probe = 9;

$iter = 10;

$consec_probes = 2; print "\n Consec probes is $consec_probes!\n";
while($consec_probes < $max_probe){
print "\n$chrom - $consec_probes probes";
if($consec_probes == 2){$thres = $data_thres; $max_thres = 6.2;}
if($consec_probes == 3){$thres = $data_thres; $max_thres = 4.2;}
if($consec_probes == 4){$thres = $data_thres; $max_thres = 2.6;}
if($consec_probes == 5){$thres = $data_thres; $max_thres = 2.2;}
if($consec_probes == 6){$thres = $data_thres; $max_thres = 1.6;}
if($consec_probes == 7){$thres = $data_thres; $max_thres = 1.2;}
if($consec_probes == 8){$thres = $data_thres; $max_thres = 1.2;}
#if($consec_probes == 9){$thres = $data_thres; $max_thres = 0.8;}
#if($consec_probes == 10){$thres = $data_thres; $max_thres = 0.8;}



while($thres < $max_thres){

 $totalfreq = 0; $shuf_no = 0;



while($shuf_no < $iter){
	
open (INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Replicate'."$replicate".'_chr'."$chrom".'_ratios_compact.txt') or die "\nCan't open file!\n";
@file_array = <INPUT>;
$num = @file_array;


@shuffled = shuffle(@file_array);
  
@file_array = ();  close INPUT;

$sec_iter = 0;

while($sec_iter < 10000){

$random_no = int(rand($num - 20));  #print "\nRandom number is $random_no";
$state = 1; 
$ln1 = $random_no; #print "\nln1 is $ln1";
$limit = $random_no + $consec_probes; #print "\nLimit is $limit";

while($ln1 < $limit){
		
		$ratio = $shuffled[$ln1];
		#print "\nRatio is $ratio and threshold is $thres!";
		if($ratio < $thres){$state = 0;}

		$ln1 = $ln1 + 1;
	}
	$totalfreq = $totalfreq + $state; #print "\nTotal freq is $totalfreq!";
	
	$sec_iter = $sec_iter + 1;
	}
	@shuffled = ();
	$shuf_no = $shuf_no + 1;
	}



	$average_freq = $totalfreq / 100000; #print "\n Average is $average_freq!";	$freq = 0;
		
			open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/shuffled_data/chr'."$chrom".'_rep'."$replicate".'_shuffled_data.txt';
			print LOG "chr$chrom\t$consec_probes\t$thres\t$average_freq\n";
			close LOG;	
						print "\n$shuf_no iterations for $consec_probes consecutive fragments above $thres ratio threshold on chr$chrom. Freq is $average_freq";
			$thres = $thres + 0.2; #print "\nThreshold moving up to $thres";
		}
		$consec_probes = $consec_probes + 1; #print "\nNumber of consecutive probes moving up to $consec_probes";
		
			 #@peak_pres = ();
			}

  #@shuffled = (); 
  
  exit;
  