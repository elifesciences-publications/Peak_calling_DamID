#!usr/bin/perl
#split_files_and_average
use warnings;


print "\nSplitting files and making average file!\n";

$exp_name = $ARGV[0]; #print"$exp_name\n";
$paths = $ARGV[1];  #print "\nFiles for processing are: $paths\n";
$rep_num = $ARGV[2]; #print "\nNumber of replicates is $rep_num\n";

if($rep_num > 0){@col = split(/\t/,$paths); $path1 = $col[0]; chomp $path1;} #print "\nPath1 is $path1\n";
if($rep_num > 1){@col = split(/\t/,$paths); $path2 = $col[1]; chomp $path2;} #print "\nPath2 is $path2\n";
if($rep_num > 2){@col = split(/\t/,$paths); $path3 = $col[2]; chomp $path3;} #print "\nPath3 is $path3\n";


open (INPUT, "$path1") or die "\nCan't open first file\n";           #opens file using the path information
@firstfile = <INPUT>;             #assigns the file data to an array
$num = @firstfile;

@col = split(/\t/,$firstfile[1]); $colnum = @col;
if($colnum == 9){$ln1 = 0;}  #if a gff file, start from the first line
if($colnum == 4){$ln1 = 1;}  #if a bedgraph file, start from the second line






open (OUTPUT, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr2L_ratios.txt');
open (OUTPUT2, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr2R_ratios.txt');
open (OUTPUT3, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr3L_ratios.txt');
open (OUTPUT4, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr3R_ratios.txt');
open (OUTPUT5, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr4_ratios.txt');
open (OUTPUT6, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chrX_ratios.txt');
open (OUTPUT7, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr2L_ratios_compact.txt');
open (OUTPUT8, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr2R_ratios_compact.txt');
open (OUTPUT9, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr3L_ratios_compact.txt');
open (OUTPUT10, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr3R_ratios_compact.txt');
open (OUTPUT11, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chr4_ratios_compact.txt');
open (OUTPUT12, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate1_chrX_ratios_compact.txt');

open (OUTPUT13, '> FDR_analysis_for_'."$exp_name".'\processed_'."$exp_name".'_average.gff');

if($colnum == 4){print OUTPUT13 "$firstfile[0]";}

while($ln1 < $num){       
	@col = split(/\t/,$firstfile[$ln1]);
	$colnum = @col; 
	if($colnum == 9){$GATC_start = $col[3]; $GATC_end = $col[4]; $ratio = $col[5];}  #if a gff file
	if($colnum == 4){$GATC_start = $col[1]; $GATC_end = $col[2]; $ratio = $col[3]; chomp $ratio;}  #if a bedgraph file
	
	if(  ($col[0] =~ m/^chr2L$/) || ($col[0] =~ m/^chr2R$/) || ($col[0] =~ m/^chr3L$/) || ($col[0] =~ m/^chr3R$/) || ($col[0] =~ m/^chr4$/) || ($col[0] =~ m/^chrX$/)  ){

	
	
		
push (@ratio1, $ratio);  
}
#####put coord and ratio into arrays ################


if($col[0] =~ m/^chr2L$/){push (@chr2L, "$GATC_start\t$GATC_end\t$ratio");}				
if($col[0] =~ m/^chr2R$/){push (@chr2R, "$GATC_start\t$GATC_end\t$ratio");}	
if($col[0] =~ m/^chr3L$/){push (@chr3L, "$GATC_start\t$GATC_end\t$ratio");}	
if($col[0] =~ m/^chr3R$/){push (@chr3R, "$GATC_start\t$GATC_end\t$ratio");}	
if($col[0] =~ m/^chr4$/){push (@chr4, "$GATC_start\t$GATC_end\t$ratio");}	
if($col[0] =~ m/^chrX$/){push (@chrX, "$GATC_start\t$GATC_end\t$ratio");}	

$ln1 = $ln1 + 1;   
}

############### sort arrays by coord and print to files ############################

$num = @chr2L; 
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;} #print "\n$AoA[0][0]\t$AoA[0][1]\n";
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT7 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT; 	@chr2L = ();  @AoA = (); @sorted_array = ();

$num = @chr2R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT2 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT8 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT2; 	@chr2R = ();  @AoA = (); @sorted_array = ();
		
$num = @chr3L;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT3 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT9 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT3; 	@chr3L = ();  @AoA = (); @sorted_array = ();			

$num = @chr3R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT4 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT10 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT4; 	@chr3R = ();  @AoA = (); @sorted_array = ();

$num = @chr4;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr4[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT5 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT11 "$sorted_array[$ln][2]\n";$ln = $ln + 1;}
		close OUTPUT5; 	@chr4 = ();  @AoA = (); @sorted_array = ();

$num = @chrX;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chrX[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT6 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT12 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT6; 	@chrX = ();  @AoA = (); @sorted_array = ();





@firstfile = (); @col = ();  
close INPUT;
close OUTPUT;
close OUTPUT2;
close OUTPUT3;
close OUTPUT4;
close OUTPUT5;
close OUTPUT6;
close OUTPUT7;
close OUTPUT8;
close OUTPUT9;
close OUTPUT10;
close OUTPUT11;
close OUTPUT12;

print "\nratio values from first file calculated\n";
###########################################################################

##########################################################################
if($rep_num > 1){


open (OUTPUT, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr2L_ratios.txt');
open (OUTPUT2, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr2R_ratios.txt');
open (OUTPUT3, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr3L_ratios.txt');
open (OUTPUT4, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr3R_ratios.txt');
open (OUTPUT5, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr4_ratios.txt');
open (OUTPUT6, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chrX_ratios.txt');
open (OUTPUT7, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr2L_ratios_compact.txt');
open (OUTPUT8, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr2R_ratios_compact.txt');
open (OUTPUT9, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr3L_ratios_compact.txt');
open (OUTPUT10, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr3R_ratios_compact.txt');
open (OUTPUT11, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chr4_ratios_compact.txt');
open (OUTPUT12, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate2_chrX_ratios_compact.txt');


open (INPUT, "$path2");
@secondfile = <INPUT>;
$num = @secondfile;






$num = @secondfile;

@col = split(/\t/,$secondfile[1]); $colnum = @col; 
if($colnum == 9){$ln1 = 0;}  #if a gff file, start from the first line
if($colnum == 4){$ln1 = 1;}  #if a bedgraph file, start from the second line


$state = 0;

while($ln1 < $num){
	@col = split(/\t/,$secondfile[$ln1]);
	
	$colnum = @col; 
	if($colnum == 9){$GATC_start = $col[3]; $GATC_end = $col[4]; $ratio2 = $col[5];}
	if($colnum == 4){$GATC_start = $col[1]; $GATC_end = $col[2]; $ratio2 = $col[3]; chomp $ratio2;}
	
	if(  ($col[0] =~ m/^chr2L$/) || ($col[0] =~ m/^chr2R$/) || ($col[0] =~ m/^chr3L$/) || ($col[0] =~ m/^chr3R$/) || ($col[0] =~ m/^chr4$/) || ($col[0] =~ m/^chrX$/)  ){
	


if($rep_num == 3){push (@ratio2, $ratio2);}

	
if($rep_num == 2){		
$average = ( ($ratio1[$state] + $ratio2) / 2); if($average ne 0){$average = sprintf("%.3f", $average);}  #averages the values and rounds up values to a certain decimal point

			if($colnum == 9){print OUTPUT13 "$col[0]\tNG\t$exp_name\t$col[3]\t$col[4]\t$average\t.\t.\t$col[8]";}    #writes value and other details to the file

			if($colnum == 4){
				
				print OUTPUT13 "$col[0]\t$GATC_start\t$GATC_end\t$average\n";
				}
				
				}		
$state = $state + 1;
}
#####put coord and ratio into arrays ################


if($col[0] =~ m/^chr2L$/){push (@chr2L, "$GATC_start\t$GATC_end\t$ratio2");}				
if($col[0] =~ m/^chr2R$/){push (@chr2R, "$GATC_start\t$GATC_end\t$ratio2");}	
if($col[0] =~ m/^chr3L$/){push (@chr3L, "$GATC_start\t$GATC_end\t$ratio2");}	
if($col[0] =~ m/^chr3R$/){push (@chr3R, "$GATC_start\t$GATC_end\t$ratio2");}	
if($col[0] =~ m/^chr4$/){push (@chr4, "$GATC_start\t$GATC_end\t$ratio2");}	
if($col[0] =~ m/^chrX$/){push (@chrX, "$GATC_start\t$GATC_end\t$ratio2");}	

$ln1 = $ln1 + 1;   
}

############### sort arrays by coord and print to files ############################

$num = @chr2L; 
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;} #print "\n$AoA[0][0]\t$AoA[0][1]\n";
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT7 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT; 	@chr2L = ();  @AoA = (); @sorted_array = ();

$num = @chr2R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT2 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT8 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT2; 	@chr2R = ();  @AoA = (); @sorted_array = ();
		
$num = @chr3L;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT3 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT9 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT3; 	@chr3L = ();  @AoA = (); @sorted_array = ();			

$num = @chr3R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT4 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT10 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT4; 	@chr3R = ();  @AoA = (); @sorted_array = ();

$num = @chr4;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr4[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT5 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT11 "$sorted_array[$ln][2]\n";$ln = $ln + 1;}
		close OUTPUT5; 	@chr4 = ();  @AoA = (); @sorted_array = ();

$num = @chrX;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chrX[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT6 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT12 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT6; 	@chrX = ();  @AoA = (); @sorted_array = ();

#@thirdfile = ();
#@ratio1 = ();
#$ratio2 = ();
close INPUT;
close OUTPUT;
close OUTPUT2;
close OUTPUT3;
close OUTPUT4;
close OUTPUT5;
close OUTPUT6;
close OUTPUT7;
close OUTPUT8;
close OUTPUT9;
close OUTPUT10;
close OUTPUT11;
close OUTPUT12;

if($rep_num == 2){close OUTPUT13; print "\nAverage file made\n";}

}

######third replicate...

if($rep_num > 2){


open (OUTPUT, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr2L_ratios.txt');
open (OUTPUT2, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr2R_ratios.txt');
open (OUTPUT3, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr3L_ratios.txt');
open (OUTPUT4, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr3R_ratios.txt');
open (OUTPUT5, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr4_ratios.txt');
open (OUTPUT6, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chrX_ratios.txt');
open (OUTPUT7, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr2L_ratios_compact.txt');
open (OUTPUT8, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr2R_ratios_compact.txt');
open (OUTPUT9, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr3L_ratios_compact.txt');
open (OUTPUT10, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr3R_ratios_compact.txt');
open (OUTPUT11, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chr4_ratios_compact.txt');
open (OUTPUT12, '> FDR_analysis_for_'."$exp_name".'\logfiles\Replicate3_chrX_ratios_compact.txt');


open (INPUT, "$path3");
@thirdfile = <INPUT>;





$num = @thirdfile;

@col = split(/\t/,$thirdfile[1]); $colnum = @col; 
if($colnum == 9){$ln1 = 0;}  #if a gff file, start from the first line
if($colnum == 4){$ln1 = 1;}  #if a bedgraph file, start from the second line

$state = 0;

while($ln1 < $num){
	@col = split(/\t/,$thirdfile[$ln1]);
	
	$colnum = @col; 
	if($colnum == 9){$GATC_start = $col[3]; $GATC_end = $col[4]; $ratio3 = $col[5];}
	if($colnum == 4){$GATC_start = $col[1]; $GATC_end = $col[2]; $ratio3 = $col[3]; chomp $ratio3;}
	
	if(  ($col[0] =~ m/^chr2L$/) || ($col[0] =~ m/^chr2R$/) || ($col[0] =~ m/^chr3L$/) || ($col[0] =~ m/^chr3R$/) || ($col[0] =~ m/^chr4$/) || ($col[0] =~ m/^chrX$/)  ){
	
	


	
if($rep_num == 3){		
$average = ( ($ratio1[$state] + $ratio2[$state] + $ratio3) / 3); if($average ne 0){$average = sprintf("%.3f", $average);}  #averages the values and rounds up values to a certain decimal point

			if($colnum == 9){print OUTPUT13 "$col[0]\tNG\t$exp_name\t$col[3]\t$col[4]\t$average\t.\t.\t$col[8]"; }   #writes value and other details to the file
			
						if($colnum == 4){
				
				print OUTPUT13 "$col[0]\t$GATC_start\t$GATC_end\t$average\n";
				}
				}		
$state = $state + 1;
}
#####put coord and ratio into arrays ################


if($col[0] =~ m/^chr2L$/){push (@chr2L, "$GATC_start\t$GATC_end\t$ratio3");}				
if($col[0] =~ m/^chr2R$/){push (@chr2R, "$GATC_start\t$GATC_end\t$ratio3");}	
if($col[0] =~ m/^chr3L$/){push (@chr3L, "$GATC_start\t$GATC_end\t$ratio3");}	
if($col[0] =~ m/^chr3R$/){push (@chr3R, "$GATC_start\t$GATC_end\t$ratio3");}	
if($col[0] =~ m/^chr4$/){push (@chr4, "$GATC_start\t$GATC_end\t$ratio3");}	
if($col[0] =~ m/^chrX$/){push (@chrX, "$GATC_start\t$GATC_end\t$ratio3");}	

$ln1 = $ln1 + 1;   
}

############### sort arrays by coord and print to files ############################

$num = @chr2L; 
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;} #print "\n$AoA[0][0]\t$AoA[0][1]\n";
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT7 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT; 	@chr2L = ();  @AoA = (); @sorted_array = ();

$num = @chr2R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr2R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT2 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT8 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT2; 	@chr2R = ();  @AoA = (); @sorted_array = ();
		
$num = @chr3L;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3L[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT3 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT9 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT3; 	@chr3L = ();  @AoA = (); @sorted_array = ();			

$num = @chr3R;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr3R[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT4 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT10 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT4; 	@chr3R = ();  @AoA = (); @sorted_array = ();

$num = @chr4;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chr4[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT5 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT11 "$sorted_array[$ln][2]\n";$ln = $ln + 1;}
		close OUTPUT5; 	@chr4 = ();  @AoA = (); @sorted_array = ();

$num = @chrX;
$ln = 0;
while($ln < $num){
		my @col = split(/\t/,$chrX[$ln]); 	push @AoA, \@col; $ln = $ln + 1;}
		@sorted_array = sort{$$a[0]<=>$$b[0]}@AoA;
		$ln = 0; while($ln < $num){print OUTPUT6 "$sorted_array[$ln][0]\t$sorted_array[$ln][1]\t$sorted_array[$ln][2]\n"; print OUTPUT12 "$sorted_array[$ln][2]\n"; $ln = $ln + 1;}
		close OUTPUT6; 	@chrX = ();  @AoA = (); @sorted_array = ();

#@thirdfile = ();
@ratio1 = ();
#$ratio2 = ();
close INPUT;
close OUTPUT;
close OUTPUT2;
close OUTPUT3;
close OUTPUT4;
close OUTPUT5;
close OUTPUT6;
close OUTPUT7;
close OUTPUT8;
close OUTPUT9;
close OUTPUT10;
close OUTPUT11;
close OUTPUT12;

if($rep_num == 3){close OUTPUT13; #print "\nAverage file made\n";}

}


}


