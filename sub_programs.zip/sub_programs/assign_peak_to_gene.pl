#!usr/bin/perl
#assign_peak_to_gene
use warnings;

$exp_name = $ARGV[0];
$FDR_thres = $ARGV[1];
$dir = $ARGV[2]; # root directory path

print "\nAssigning genes to peaks\n";

open (INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/final_peak_file_for_'."$exp_name".'_FDR_'."$FDR_thres".'_with_peak_height_and_highest_assoiciated_FDR.gff');
@positions = <INPUT>;

open OUTPUT, '> '."$dir".'/FDR_analysis_for_'."$exp_name".'/full_gene_list_for_'."$exp_name".'.txt';



$genenum = @geneinfo;
POLII_analysis("chr2L");
POLII_analysis("chr2R");
POLII_analysis("chr3L");
POLII_analysis("chr3R");
POLII_analysis("chr4");
POLII_analysis("chrX");

sub POLII_analysis{

	my $chrom = shift; #print "\nChrom is $chrom";





	foreach $a (@positions){
		@col = split(/\t/,$a);
		if($col[0] =~ m/$chrom/){push @peak_pos, "$col[0]\t$col[3]\t$col[4]\t$col[6]\t$col[7]\n";}
		}

	
open INPUT2, "$dir".'/gene_info/gene_ranges_'."$chrom".'_r6.11.txt' or die "\nCan't open gene ranges file!\n";
@geneinfo = <INPUT2>;
$genenum = @geneinfo;
close INPUT2;


foreach $b (@peak_pos){
	
	@col = split(/\t/,$b);
	$chrom = $col[0];
	$start = $col[1];
	$end = $col[2];
	$height = $col[3];
	$FDR = $col[4]; chomp $FDR;
	
	
	$ln = 1;
	$state = 0;
	
	while($ln < $genenum){
	
	@genecol = split(/\t/,$geneinfo[$ln]);
	@id = split(/;/,$genecol[4]);
	$symbol = $id[0];
	$FBgn = $id[1];
	
				if((($start >= $genecol[1]) && ($start <= $genecol[2])) || (($end <= $genecol[2]) && ($end >= $genecol[1]))){
	  				print OUTPUT "$chrom\t$start\t$end\t$height\t$FDR\t$symbol\t$FBgn";
	  				$state = 1;
	  				}
	  				if(($state == 1) && ($genecol[1] > ($end + 50000))){
	  					$ln = $genenum;
	  					}
						$ln = $ln + 1;									
												}
												
											}
											


#print "\nGenes assigned for chrom $chrom!";
@peak_pos = (); @geneinfo = ();
}
close INPUT;  close INPUT2;
print "\nAll done!\n";
exit;


exit;
											