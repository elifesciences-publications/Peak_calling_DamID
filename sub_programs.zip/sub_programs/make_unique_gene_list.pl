#!usr/bin/perl
#make_unique_gene_list
use warnings;


print "\nMaking unique gene list";


$exp_name = $ARGV[0]; #print "exp_name is $exp_name\n";
$dir = $ARGV[1]; # root directory path

	  			               	open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/unique_gene_results_for_'."$exp_name".'.txt';
													print LOG "Gene\tFBgn\tPeak info\tPeak height\tFDR\n"; 
													close LOG;






chrom_analysis("2L");
chrom_analysis("2R");
chrom_analysis("3L");
chrom_analysis("3R");
chrom_analysis("X");
chrom_analysis("4");

sub chrom_analysis{  ####don't forget to close bracket!
	
	my $chrom = shift; my $chrom2 = "chr"."$chrom";

open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/full_gene_list_for_'."$exp_name".'.txt' or die "\nCan't open full results file for chr $chrom\n";
@results = <INPUT>; 
$resultsnum = @results;

$ln1 = 0;

while($ln1 < $resultsnum){
	my @col = split(/\t/,$results[$ln1]);
	if($col[0] =~ m/$chrom/){
	
push @array, \@col;}
	$ln1 = $ln1 + 1;	    
	 		}


@sorted_array_1 = sort{$$a[6]cmp$$b[6]}@array;   ###sort by gene name
$num = @sorted_array_1; #print "\nSorted array is $num big!\n";



$ln1 = 0;

while($ln1 < ($num - 1)){
		$gene = $sorted_array_1[$ln1][5]; #chomp $gene; 
		$FBgn = $sorted_array_1[$ln1][6]; chomp $FBgn;
		$FDR =  $sorted_array_1[$ln1][4];
		$height = $sorted_array_1[$ln1][3];
		$peakstart = $sorted_array_1[$ln1][1];
		$peakend = $sorted_array_1[$ln1][2];
		$peak_info = "$chrom2:$peakstart..$peakend";
		
	if($sorted_array_1[$ln1][6] eq $sorted_array_1[$ln1 + 1][6]){
		push (@miniarray, "$gene\t$FBgn\t$peak_info\t$height\t$FDR\n");
		
	}else{
		push (@miniarray, "$gene\t$FBgn\t$peak_info\t$height\t$FDR\n");
		$min_num = @miniarray; #print "\nsize of miniarray is $min_num";
		$ln2 = 0;
		while($ln2 < $min_num){
	my @minicol = split(/\t/,$miniarray[$ln2]); 
	push @AoA, \@minicol; #print "\n$AoA[0][0]\t$AoA[0][1]\t$AoA[0][2]\t$AoA[0][3]t\$AoA[0][4]";
	$ln2 = $ln2 + 1;	    
	 		}
	 		@mini_sorted_array = sort{$$b[3]<=>$$a[3]}@AoA; #$sortnum = @mini_sorted_array; #print "\nsize of mini sorted array is $sortnum";
	 		@mini_sorted_array2 = sort{$$a[4]<=>$$b[4]}@mini_sorted_array;
	 		
	 		
	  			               	open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/unique_gene_results_for_'."$exp_name".'.txt';
													print LOG "$mini_sorted_array2[0][0]\t$mini_sorted_array2[0][1]\t$mini_sorted_array2[0][2]\t$mini_sorted_array2[0][3]\t$mini_sorted_array2[0][4]";
													close LOG;	
					
					@miniarray = ();
					@mini_sorted_array = ();
					@mini_sorted_array2 = ();
					@AoA = ();
				}
				$ln1 = $ln1 + 1;
			}	
	
	
					  	
	  		$lastgene = $sorted_array_1[$num - 1][5]; 
	  		#print "\nLast line is $sorted_array_1[$num - 1][0]\t$sorted_array_1[$num - 1][1]\t$sorted_array_1[$num - 1][2]\t$sorted_array_1[$num - 1][3]\t$sorted_array_1[$num - 1][4]\n";
	  		#print "\nSecond to last line is $sorted_array_1[$num - 2][0]\t$sorted_array_1[$num - 2][1]\t$sorted_array_1[$num - 2][2]\t$sorted_array_1[$num - 2][3]\t$sorted_array_1[$num - 2][4]\n";
	  		
	  		if($lastgene ne $sorted_array_1[$num - 2][5]){
	  			               $Fbgn = $sorted_array_1[$num - 1][6]; chomp $Fbgn;
	  			               
	  			              	open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/unique_gene_results_for_'."$exp_name".'.txt';
													print LOG "$lastgene\t$Fbgn\t$sorted_array_1[$num - 1][0]:$sorted_array_1[$num - 1][1]..$sorted_array_1[$num - 1][2]\t$sorted_array_1[$num - 1][3]\t$sorted_array_1[$num - 1][4]\n";  print "\n$lastgene\t$Fbgn\t$sorted_array_1[$num - 1][0]:$sorted_array_1[$num - 1][1]..$sorted_array_1[$num - 1][2]\t$sorted_array_1[$num - 1][3]\t$sorted_array_1[$num - 1][4]\n";
													close LOG;
												}	
	






@array = ();
@sorted_array_1 = ();
#@sorted_array_2 = ();
#@results2 = ();
close INPUT;
@results = ();

}
print "\nAll finished!\n";
exit;			