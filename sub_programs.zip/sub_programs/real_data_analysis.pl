#!usr/bin/perl
#real_data_analysis
use warnings;

$exp_name = $ARGV[0]; #print "exp_name is $exp_name\n";
$chrom = $ARGV[1];  #print "chrom is $chrom\n";
$replicate = $ARGV[2]; #print "replicate is $replicate\n";
$data_thres = $ARGV[3]; #print "Data threshold is $data_thres\n";
$dir = $ARGV[4]; # root directory path

#$exp_name = "GG_test2"; print "exp_name is $exp_name\n";
#$chrom = "2L";  print "chrom is $chrom\n";
#$replicate = 2;
#$data_thres = 50;

print"\nAnalysing real data\n";

open (INPUT2, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Replicate'."$replicate".'_chr'."$chrom".'_ratios.txt') or die "\nCan't open file!\n";
@file_array_full = <INPUT2>;
$num = @file_array_full;

  

$consec_probes = 2;
while($consec_probes < 9){

if($consec_probes == 2){$thres = $data_thres; $maxthres = 6.2}
if($consec_probes == 3){$thres = $data_thres; $maxthres = 4.2}
if($consec_probes == 4){$thres = $data_thres; $maxthres = 2.6}
if($consec_probes == 5){$thres = $data_thres; $maxthres = 2.2}
if($consec_probes == 6){$thres = $data_thres; $maxthres = 1.6}
if($consec_probes == 7){$thres = $data_thres; $maxthres = 1.2}
if($consec_probes == 8){$thres = $data_thres; $maxthres = 1.2}
#if($consec_probes == 9){$thres = $data_thres; }
#if($consec_probes == 10){$thres = $data_thres; }
#if($consec_probes == 15){$thres = 0.1; }
#if($consec_probes >= 16){$thres = 1; }
#$max_thres = 5.05;
#$thres = 1;

while($thres < $maxthres){
$ln1 = 9; $freq = 0; 
	
  $state = 0; $state2 = 0;
  
		      
	while($ln1 < $num){
		#@rep1col = split(/\t/,$rep1_data[$ln1]);
				#@rep2col = split(/\t/,$rep2_data[$ln1]);
						#@rep3col = split(/\t/,$rep3_data[$ln1]);
						
		@colminus1 = split(/\t/,$file_array_full[$ln1 - 1]);	
		@col = split(/\t/,$file_array_full[$ln1]);		
		$ratio = $col[2];
		if($ratio >= $thres) {$state = $state + 1;}
		if($ratio >= $thres) {$state2 = 1;}
		if(($ratio < $thres)  && ($state == $consec_probes) && ($state2 == 1))   
		               {$freq = $freq + 1; $state = 0; $state2 = 0;
		#@colminus21 = split(/\t/,$file_array_full[$ln1 - 21]);  
		#@colminus20 = split(/\t/,$file_array_full[$ln1 - 20]); 	
		#@colminus19 = split(/\t/,$file_array_full[$ln1 - 19]); 		
		#@colminus18 = split(/\t/,$file_array_full[$ln1 - 18]); 		
		#@colminus17 = split(/\t/,$file_array_full[$ln1 - 17]); 				
		#@colminus16 = split(/\t/,$file_array_full[$ln1 - 16]);  
		#@colminus15 = split(/\t/,$file_array_full[$ln1 - 15]); 	
		#@colminus14 = split(/\t/,$file_array_full[$ln1 - 14]); 		
		#@colminus13 = split(/\t/,$file_array_full[$ln1 - 13]); 		
		#@colminus12 = split(/\t/,$file_array_full[$ln1 - 12]); 		
		#@colminus11 = split(/\t/,$file_array_full[$ln1 - 11]); 		
		@colminus10 = split(/\t/,$file_array_full[$ln1 - 10]); 		
		@colminus9 = split(/\t/,$file_array_full[$ln1 - 9]);		               	
		@colminus8 = split(/\t/,$file_array_full[$ln1 - 8]);  
		@colminus7 = split(/\t/,$file_array_full[$ln1 - 7]); 	
		@colminus6 = split(/\t/,$file_array_full[$ln1 - 6]); 		
		@colminus5 = split(/\t/,$file_array_full[$ln1 - 5]); 		
		@colminus4 = split(/\t/,$file_array_full[$ln1 - 4]); 		
		@colminus3 = split(/\t/,$file_array_full[$ln1 - 3]); 		
		@colminus2 = split(/\t/,$file_array_full[$ln1 - 2]); 		
		@colminus1 = split(/\t/,$file_array_full[$ln1 - 1]); 
		@col = split(/\t/,$file_array_full[$ln1]);         
		
		
		
																									 push (@pos_array, "$col[0]"); push (@pos_array2, "$col[1]");
																									 push (@pos_array, "$colminus1[0]"); push (@pos_array2, "$colminus1[1]");
																									 push (@pos_array, "$colminus2[0]"); push (@pos_array2, "$colminus2[1]");
																									 push (@pos_array, "$colminus3[0]"); push (@pos_array2, "$colminus3[1]");
																									 push (@pos_array, "$colminus4[0]"); push (@pos_array2, "$colminus4[1]");
																									 push (@pos_array, "$colminus5[0]"); push (@pos_array2, "$colminus5[1]");
																									 push (@pos_array, "$colminus6[0]"); push (@pos_array2, "$colminus6[1]");
																									 push (@pos_array, "$colminus7[0]"); push (@pos_array2, "$colminus7[1]");
																									 push (@pos_array, "$colminus8[0]"); push (@pos_array2, "$colminus8[1]");
				               														 push (@pos_array, "$colminus9[0]"); push (@pos_array2, "$colminus9[1]");
				               														 
				               														 push (@pos_array, "$colminus10[0]"); push (@pos_array2, "$colminus10[1]");
				               																				
				               																				#push (@pos_array, "$colminus11[0]");push (@pos_array, "$colminus12[0]");
		               			               														#push (@pos_array, "$colminus13[0]");push (@pos_array, "$colminus14[0]");push (@pos_array, "$colminus15[0]");push (@pos_array, "$colminus16[0]");
		               																										#push (@pos_array, "$colminus17[0]");push (@pos_array, "$colminus18[0]");push (@pos_array, "$colminus19[0]");push (@pos_array, "$colminus20[0]"); push (@pos_array, "$colminus21[0]");
		               	
		               	 			if($thres >= 0.2){ #don't need to record ranges for peaks below log1
		               	 			
		               	 			open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/FDR_results/chr'."$chrom".'_rep'."$replicate".'_peak_data.txt';
													print LOG "chr$chrom\t$consec_probes\t$thres\t$pos_array[$consec_probes]\t$pos_array2[1]\n";
													close LOG;
												}
												 
													 @pos_array = (); @pos_array2 = (); 
		               	    }
		if($ratio < $thres){$state = 0; $state2 = 0;}
		$ln1 = $ln1 + 1;
	}

		
			open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/freq_data/chr'."$chrom".'_rep'."$replicate".'data.txt';
			print LOG "chr$chrom\t$consec_probes\t$thres\t$freq\n";
			close LOG;	
						#print "\n$consec_probes consecutive probes above $thres threshold on chr$chrom. Freq is $freq";
			$thres = $thres + 0.2; 
		}
		$consec_probes = $consec_probes + 1; 
			}
	@file_array_full = ();  close INPUT2;
	exit;
