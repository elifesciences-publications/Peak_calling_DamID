#!usr/bin/perl
#make_unique_gene_list
use warnings;


#$exp_name = "GG_test3"; print "exp_name is $exp_name\n";
#$chrom = "2L";
#$replicate = 1;
#$FDR_cut_off = 0.01;

$exp_name = $ARGV[0]; print "exp_name is $exp_name\n";
$chrom = $ARGV[1];  print "chrom is $chrom\n";
$replicate = $ARGV[2]; print "replicate is $replicate\n";
$FDR_cut_off = $ARGV[3]; print "FDR threshold is $FDR_cut_off\n";
$dir = $ARGV[4]; # root directory path

print "\nMaking peak file\n";

open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/chr'."$chrom".'_rep'."$replicate".'_each_GATC_frag_with_data_and_lowest_FDR.txt' or die "\nCan't open lowest FDR file for chr $chrom\n";
@results = <INPUT>; 
$resultsnum = @results;

$ln1 = 0;

while($ln1 < $resultsnum){
	my @col = split(/\t/,$results[$ln1]);
	if($col[3] < $FDR_cut_off){push @AoA, \@col;}
	$ln1 = $ln1 + 1;
}

$ln1 = 0; $num2 = @AoA; $state = 0; $state2 = 0;

$start = $AoA[0][0];

	while($ln1 < ($num2 - 1)){
		
		if($AoA[$ln1][1] == $AoA[$ln1 + 1][0]){$state = 1; if($state2 == 0){$start = $AoA[$ln1][0]} $state2 = 1;}
		


		if(($AoA[$ln1][1] != $AoA[$ln1 + 1][0]) && ($state == 1)){

																					open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Rep'."$replicate".'_peak_file.gff';
																					print LOG "chr$chrom\t.\t$exp_name\t$start\t$AoA[$ln1][1]\t1\t.\t.\t.\n";
																					close LOG;  
																					$state = 0; $state2 = 0;
																				}		

																				
																				
																				
				if(($AoA[$ln1][1] != $AoA[$ln1 + 1][0]) && ($state == 1) && ($ln1 == (num2 - 2))){

																					open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Rep'."$replicate".'_peak_file.gff';
																					print LOG "chr$chrom\t.\t$exp_name\t$start\t$AoA[$ln1 + 1][1]\t1\t.\t.\t.\n";
																				close LOG;  
																					$state = 0; 
																				}																		
																				
																				
																				
				if(($ln1 == ($num2 - 1)) && ($state = 0)){
																					open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Rep'."$replicate".'_peak_file.gff';
																					print LOG "chr$chrom\t.\t$exp_name\t$AoA[$ln1][0]\t$AoA[$ln1][1]\t1\t.\t.\t.\n";
																					close LOG;  
																					
																				}	
											
											$ln1 = $ln1 + 1;
										}


exit;			