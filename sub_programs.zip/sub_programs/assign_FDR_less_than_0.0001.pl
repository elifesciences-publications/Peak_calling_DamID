#!usr/bin/perl
#assign_FDR_less_than_0.0001
use warnings;


$exp_name = $ARGV[0]; #print "exp_name is $exp_name\n";
$chrom = $ARGV[1];  #print "chrom is $chrom\n";
$replicate = $ARGV[2]; #print "replicate is $replicate\n";
$data_thres = $ARGV[3]; #print "Data threshold is $data_thres\n";
$dir = $ARGV[4]; # root directory path

#$exp_name = "test2"; print "exp_name is $exp_name\n";
#$chrom = "2L";  print "chrom is $chrom\n";
#$replicate = "1"; print "replicate is $replicate\n";

print "\nFind regions with FDR < 0.0001\n";

open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Replicate'."$replicate".'_chr'."$chrom".'_ratios.txt' or die "\ncan't open unshuffled file!";
@realdata = <INPUT>;
$num = @realdata;


$max_probe = 11;

$consec_probes = 2; #print "\n Consec probes is $consec_probes!\n";
while($consec_probes < $max_probe){
print "\n$chrom - $consec_probes probes";
if($consec_probes == 2){$max_thres = 6;}
if($consec_probes == 3){$max_thres = 4;}
if($consec_probes == 4){$max_thres = 2.4;}
if($consec_probes == 5){$max_thres = 2;}
if($consec_probes == 6){$max_thres = 1.4;}
if($consec_probes == 7){$max_thres = 1;}
if($consec_probes == 8){$max_thres = 1;}
if($consec_probes == 9){$max_thres = $data_thres;}
if($consec_probes == 10){$max_thres = $data_thres;}

$ln1 = 1; $state = 0;

while($ln1 < $num){
	
	@colminus1 = split(/\t/,$realdata[$ln1 - 1]);
	@col = split(/\t/,$realdata[$ln1]);

if(($colminus1[2] <= $max_thres) && ($col[2] > $data_thres) && ($state == 0)){$start = $col[0]; $state = $state + 1;}
	if(($colminus1[2] > $max_thres) && ($state > 0)){$state = $state + 1;} 
	#if( ($col[0] - $colminus1[0]) > 1000){$state = 0;}

	if(($col[2] < $max_thres)  && ($state == ($consec_probes + 1))){
		     $endofrange = $colminus1[1];
		               	 			open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/FDR_results/chr'."$chrom".'_rep'."$replicate".'_range_data_for_0FDR.txt';
													print LOG "$start\t$endofrange\n";
													close LOG;  #print "\nrange info assigned";
													$state = 0;
												}
			if($col[2] < $max_thres){$state = 0;}	
						
												$ln1 = $ln1 + 1;

}



$consec_probes = $consec_probes + 1;
}

	#map all the regions with other 10 counts over more tha 10 consecutive GATC frags
$ln1 = 1; $state = 0;

while($ln1 < $num){
	@colminus1 = split(/\t/,$realdata[$ln1 - 1]);
	@col = split(/\t/,$realdata[$ln1]);

	if(($colminus1[2] < $data_thres) && ($col[2] >= $data_thres) && ($state == 0)){$start = $col[0]; $state = $state + 1;}
	if(($colminus1[2] >= $data_thres) && ($state > 0)){$state = $state + 1;} 
	#if( ($col[0] - $colminus1[0]) > 1000){$state = 0;}

	if(($col[2] < $data_thres)  && ($state > 11)){
		     $endofrange = $colminus1[1];
		               	 			open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/FDR_results/chr'."$chrom".'_rep'."$replicate".'_range_data_for_0FDR.txt';
													print LOG "$start\t$endofrange\n";
													close LOG;  #print "\nrange info assigned";
													$state = 0;
												}
			if($col[2] < $data_thres){$state = 0;}	
						
												$ln1 = $ln1 + 1;

											}
											
											#print "\nFinished assigning FDR rates > 0.0001\n";
@colminus1 = ();
@col = ();
@realdata = ();
close INPUT;