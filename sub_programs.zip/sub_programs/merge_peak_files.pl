#!usr/bin/perl
#merge_peak_files2
use warnings;


$exp_name = $ARGV[0];
$rep_num = $ARGV[1];
$dir = $ARGV[2]; # root directory path

print "\nFinding GATC fragments that are present in all significant peaks in all replicates\n";

open INPUT, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Rep1_peak_file.gff';
@peaks1 = <INPUT>; 
#$peaksnum1 = @peaks1;


chrom_analysis("2L");
chrom_analysis("2R");
chrom_analysis("3L");
chrom_analysis("3R");
chrom_analysis("X");
chrom_analysis("4");

sub chrom_analysis{  ####don't forget to close bracket!
	
	my $chrom = shift;
	my $chrom2 = "chr"."$chrom"; #print "\n$chrom2\n";
	
foreach $f (@peaks1){
	@peakcol = split(/\t/,$f);
if($peakcol[0] =~ m/$chrom/){push @peaks1_filter, $f;}	}
	

open (INPUT2, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Replicate1_chr'."$chrom".'_ratios.txt');
@ratios = <INPUT2>;

foreach $a (@ratios){
	@col = split(/\t/,$a);
	push @GATCs, "$col[0]\t$col[1]";
}
@ratios = (); close INPUT2;

foreach $a (@peaks1_filter){

@col = split(/\t/,$a);

foreach $b (@GATCs){
@col2 = split(/\t/,$b); 

if(($col2[0] >= $col[3]) && ($col2[0] < $col[4])){

push @rep1_GATCs, $b;

if($rep_num == 1){
open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/GATC_frags_forming_peaks.gff';
print LOG "$chrom2\t$b\n";
close LOG;
}


}
}
}  print "\nFound all GATCs in rep1 for $chrom\n";

if($rep_num == 2){
	

open INPUT3, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Rep2_peak_file.gff';
@peaks2 = <INPUT3>; 
#$peaksnum2 = @peaks2;

foreach $g (@peaks2){
	@peakcol = split(/\t/,$g);
	if($peakcol[0] =~ m/$chrom/){push @peaks2_filter, "$peakcol[3]\t$peakcol[4]";}
}
@peaks2 = ();

foreach $a (@rep1_GATCs){
@col2 = split(/\t/,$a); 

foreach $b (@peaks2_filter){
@col = split(/\t/,$b);
if(($col2[0] >= $col[0]) && ($col2[0] < $col[1])){

open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/GATC_frags_forming_peaks.gff';
print LOG "$chrom2\t$a\n";
close LOG;
}
}
}
}


if($rep_num == 3){  

open INPUT3, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Rep2_peak_file.gff' ;
@peaks2 = <INPUT3>; 
#$peaksnum2 = @peaks2;

foreach $g (@peaks2){
	@peakcol = split(/\t/,$g);
	if($peakcol[0] =~ m/$chrom/){push @peaks2_filter, "$peakcol[3]\t$peakcol[4]";}
}
@peaks2 = ();

foreach $a (@rep1_GATCs){
@col2 = split(/\t/,$a); 

foreach $b (@peaks2_filter){
@col = split(/\t/,$b);
if(($col2[0] >= $col[0]) && ($col2[0] < $col[1])){

push @rep1_and_rep2_GATCs, $a; #print"\n$a";

}
}
} print"\nGATCs in both rep1 and rep2 found\n";

open INPUT4, "$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/Rep3_peak_file.gff';
@peaks3 = <INPUT4>;

foreach $g (@peaks3){
	@peakcol = split(/\t/,$g);
	if($peakcol[0] =~ m/$chrom/){push @peaks3_filter, "$peakcol[3]\t$peakcol[4]";}
}
foreach $c (@rep1_and_rep2_GATCs){
	@col2 = split(/\t/,$c); 	
	
	foreach $d (@peaks3_filter){
@col = split(/\t/,$d);
if(($col2[0] >= $col[0]) && ($col2[0] < $col[1])){
	 
open LOG, '>> '."$dir".'/FDR_analysis_for_'."$exp_name".'/logfiles/GATC_frags_forming_peaks.gff';
print LOG "$chrom2\t$c\n";
close LOG;
}
}
}


}
@rep1_GATCs = ();
@peaks3_filter = (); 
@rep1_and_rep2_GATCs = ();
@peaks2_filter = ();
@GATCs = ();
@peaks1_filter = ();

}